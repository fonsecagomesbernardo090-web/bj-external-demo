package com.bj.external;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 77;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 40, 28, 28);
        page.setBackgroundColor(Color.rgb(18,18,24));

        TextView title = new TextView(this);
        title.setText("B.J EXTERNAL");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 10, 0, 24);
        page.addView(title);

        TextView info = new TextView(this);
        info.setText("Painel flutuante demonstrativo. Não se conecta ao Free Fire e não detecta inimigos reais.");
        info.setTextColor(Color.LTGRAY);
        info.setTextSize(15);
        info.setPadding(0, 0, 0, 24);
        page.addView(info);

        Button start = new Button(this);
        start.setText("ATIVAR PAINEL FLUTUANTE");
        page.addView(start);
        start.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) {
                startService(new Intent(this, OverlayService.class));
                finish();
            } else {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, REQ_OVERLAY);
            }
        });

        Button stop = new Button(this);
        stop.setText("PARAR PAINEL");
        page.addView(stop);
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));

        setContentView(page);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQ_OVERLAY && Settings.canDrawOverlays(this)) {
            startService(new Intent(this, OverlayService.class));
            finish();
        }
    }
}
