package com.bj.external;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private View panel;
    private boolean expanded = true;
    private int colorIndex = 0;
    private final int[] colors = { Color.RED, Color.GREEN, Color.CYAN, Color.YELLOW, Color.MAGENTA };
    private TextView box, line, life, colorLabel;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        buildPanel();
    }

    private TextView text(String value, int size) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setPadding(10, 8, 10, 8);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this); b.setText(value); return b;
    }

    private void buildPanel() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(10, 8, 10, 8);
        outer.setBackgroundColor(Color.rgb(24,24,32));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("B.J EXTERNAL  •  DEMO", 14);
        title.setTypeface(null, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button close = button("×");
        header.addView(close);
        outer.addView(header);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        box = text("ESP CAIXA: ON (simulado)", 13);
        line = text("ESP LINHA: ON (simulado)", 13);
        life = text("ESP VIDA: ON (simulado)", 13);
        controls.addView(box); controls.addView(line); controls.addView(life);
        Button toggleBox = button("Alternar caixa");
        Button toggleLine = button("Alternar linha");
        Button toggleLife = button("Alternar vida");
        Button color = button("Mudar cor");
        colorLabel = text("Cor atual: vermelha", 12);
        controls.addView(toggleBox); controls.addView(toggleLine);
        controls.addView(toggleLife); controls.addView(color);
        controls.addView(colorLabel);
        outer.addView(controls);

        close.setOnClickListener(v -> {
            expanded = !expanded;
            controls.setVisibility(expanded ? View.VISIBLE : View.GONE);
            close.setText(expanded ? "−" : "+");
        });
        toggleBox.setOnClickListener(v -> box.setText(box.getText().toString().contains("ON") ?
            "ESP CAIXA: OFF (simulado)" : "ESP CAIXA: ON (simulado)"));
        toggleLine.setOnClickListener(v -> line.setText(line.getText().toString().contains("ON") ?
            "ESP LINHA: OFF (simulado)" : "ESP LINHA: ON (simulado)"));
        toggleLife.setOnClickListener(v -> life.setText(life.getText().toString().contains("ON") ?
            "ESP VIDA: OFF (simulado)" : "ESP VIDA: ON (simulado)"));
        color.setOnClickListener(v -> {
            colorIndex = (colorIndex + 1) % colors.length;
            int c = colors[colorIndex];
            box.setTextColor(c); line.setTextColor(c); life.setTextColor(c);
            String[] names = {"vermelha","verde","azul","amarela","rosa"};
            colorLabel.setText("Cor atual: " + names[colorIndex]);
        });

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = 20; p.y = 120;
        panel = outer;
        wm.addView(panel, p);

        header.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY; float touchX, touchY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = p.x; startY = p.y; touchX = e.getRawX(); touchY = e.getRawY(); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    p.x = startX + (int)(e.getRawX()-touchX);
                    p.y = startY + (int)(e.getRawY()-touchY);
                    wm.updateViewLayout(panel, p); return true;
                }
                return e.getAction() == MotionEvent.ACTION_UP;
            }
        });
    }

    @Override public void onDestroy() {
        if (wm != null && panel != null) wm.removeView(panel);
        super.onDestroy();
    }
}
